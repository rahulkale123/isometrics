# Designer Workspace Illustrations
This freebie was made by [Polar Vectors](https://polarvectors.com/) exclusively for Codrops.
Use it freely for personal and commercial purposes but please don't sell them as-is or redistribute them. 

Read more about it here: [Designer Workspace Illustrations Freebie](https://tympanus.net/codrops/?p=34233)

Follow Polar Vectors: [Instagram](https://www.instagram.com/diana.hlevnjak/), [Facebook](https://www.facebook.com/polarvectors/), [Twitter](https://twitter.com/PolarVectors), [Dribbble](https://dribbble.com/DianaHlevnjak)

Follow Codrops: [Twitter](http://www.twitter.com/codrops), [Facebook](http://www.facebook.com/codrops), [Google+](https://plus.google.com/101095823814290637419), [GitHub](https://github.com/codrops), [Pinterest](http://www.pinterest.com/codrops/), [Instagram](https://www.instagram.com/codropsss/)


[© Codrops 2018](http://www.codrops.com)